# Kamailio - Interrogating-CSCF Example Configuration File

Project Website:

  * http://www.kamailio.org

## Database Structure

The necessary Database files for the Interrogating-CSCF are included in this folder.

