# Kamailio - Proxy-CSCF Example Configuration File

Project Website:

  * http://www.kamailio.org

## Database Structure

The necessary Database files for the Proxy-CSCF can be found in the utils/kamctl/mysql/ folder.

The following tables (or files) are required:

  * ims_dialog-create.sql
  * ims_usrloc_pcscf-create.sql
  * presence-create.sql
  * standard-create.sql
