Now supported dists:

1. OpenSUSE Leap 42.2
1. OpenSUSE Leap 42.3
1. OpenSUSE Tumbleweed

SPEC file and other stuff located at `../obs` folder
