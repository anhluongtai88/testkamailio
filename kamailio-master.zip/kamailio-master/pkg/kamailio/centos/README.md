Now supported dists:

1. CentOS 6
1. CentOS 7

SPEC file and other stuff located at `../obs` folder
