Now supported dists:

1. Fedora 25
1. Fedora 26

SPEC file and other stuff located at `../obs` folder
