Now supported dists:

1. Oracle Linux 6
1. Oracle Linux 7

SPEC file and other stuff located at `../obs` folder
