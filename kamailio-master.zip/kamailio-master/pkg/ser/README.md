# Packaging SER Application #

Specs for packaging SER were removed, not being maintained for very long time.

See the specs for Kamailio packaging for up to date rules, they are located at:

  * pkg/kamailio/

For questions, email to sr-dev@lists.kamailio.org .
